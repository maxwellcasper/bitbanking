<?php

namespace App\Updates;

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class MigrationVer2118114 implements UpdaterInterface
{
    const VERSION = 21181141;

    public function getVersion()
    {
        return self::VERSION;
    }

    public function handle()
    {
        $this->addPaymentMaxAmount();
        $this->addWithdrawMaxAmount();
    }

    private function addPaymentMaxAmount()
    {
        if (Schema::hasColumn('payment_methods', 'max_amount')) return;
                
        Schema::table('payment_methods', function (Blueprint $table) {
            $table->string('max_amount')->nullable();
        });
    }

    private function addWithdrawMaxAmount()
    {
        if (Schema::hasColumn('withdraw_methods', 'max_amount')) return;
                
        Schema::table('withdraw_methods', function (Blueprint $table) {
            $table->string('max_amount')->nullable();
        });
    }
}
