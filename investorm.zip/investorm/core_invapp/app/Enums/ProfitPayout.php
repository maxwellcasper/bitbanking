<?php


namespace App\Enums;


interface ProfitPayout
{
    const EVERYTIME = 'everytime';
    const THRESHOLD = 'threshold';
}
