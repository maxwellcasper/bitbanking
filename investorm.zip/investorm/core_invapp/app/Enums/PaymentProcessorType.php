<?php


namespace App\Enums;


interface PaymentProcessorType
{
    const PAYMENT = 'payment';
    const WITHDRAW = 'withdraw';
}
