<?php


namespace App\Enums;


interface EmailRecipientType
{
    const ADMIN = 'admin';
    const CUSTOMER = 'customer';
}
